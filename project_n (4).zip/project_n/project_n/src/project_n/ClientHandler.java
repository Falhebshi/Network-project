/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project_n;

/**
 *
 * @author memem
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

class ClientHandler implements Runnable {
    private Socket client;
    private BufferedReader in;
    private PrintWriter out;
    private ArrayList<ClientHandler> clients;
    private ArrayList<String> usernames;
    private ArrayList<String> passwords;
    private ArrayList<String> reservedSlots;

    public ClientHandler(Socket c, ArrayList<ClientHandler> clients, ArrayList<String> usernames,
            ArrayList<String> passwords, ArrayList<String> reservedSlots) throws IOException {
        this.client = c;
        this.clients = clients;
        this.usernames = usernames;
        this.passwords = passwords;
        this.reservedSlots = reservedSlots;

        in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        out = new PrintWriter(client.getOutputStream(), true);
    }

    @Override
    public void run() {
        try {
            // Step 1: Ask for username and password
            String username = in.readLine();
            String password = in.readLine();
            String logintype = in.readLine();

            while (logintype != null) {
                if (logintype.equalsIgnoreCase("new")) {
                    synchronized (usernames) {
                        if (usernames.contains(username)) {
                            out.println("Username already exists! Please try again.");
                            client.close();
                            return;
                        } else {
                            usernames.add(username);
                            passwords.add(password);
                            out.println("Registration successful! Welcome, " + username + "!");
                        }
                    }
                } else if (logintype.equalsIgnoreCase("exist")) {
                    synchronized (usernames) {
                        int idx = usernames.indexOf(username);
                        if (idx >= 0) {
                            String storedPass = passwords.get(idx);
                            if (storedPass != null && storedPass.equals(password)) {
                                out.println("You are connected and logged in successfully.");
                                break; // ✅ use break, not return — continue to reservation stage
                            } else {
                                out.println("Incorrect password. Please try again.");
                                client.close();
                                return;
                            }
                        } else {
                            out.println("Username does not exist. Please register.");
                            client.close();
                            return;
                        }
                    }
                } else if (logintype.equalsIgnoreCase("quit")) {
                    out.println("Goodbye!");
                    return;
                } else {
                    out.println("UNKNOWN COMMAND");
                }
            }

            // Step 2: Reservation handling
            String line;
            while ((line = in.readLine()) != null) {
                if (line.startsWith("RESERVE") && line.length() > 7 && line.charAt(7) == ' ') {
                    String[] parts = line.split(" ");
                    if (parts.length < 4) {
                        out.println("REJECTED: Invalid format. Use RESERVE <Sport> <Day> <Time>");
                        continue;
                    }

                    String sport = parts[1];
                    String day = parts[2];
                    String time = parts[3];
                    String slotKey = sport + "-" + day + "-" + time;

                    // ✅ Reservation is now thread-safe
                    synchronized (reservedSlots) {
                        if (reservedSlots.contains(slotKey)) {
                            out.println("REJECTED: Slot already reserved, choose another time.");
                        } else {
                            reservedSlots.add(slotKey);
                            out.println("CONFIRMED: " + slotKey + " reserved successfully!");
                        }
                    }
                } else if (line.equalsIgnoreCase("QUIT")) {
                    out.println("Goodbye!");
                    break;
                } else {
                    out.println("UNKNOWN COMMAND");
                }
            }

        } catch (IOException e) {
            System.out.println("Client disconnected.");
        } finally {
            try {
                client.close();
            } catch (IOException e) {
                System.out.println("Error closing connection.");
            }
        }
    }
}
