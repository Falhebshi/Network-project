package project_n;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class ReservationServer {

    // to store the client threads
    private static final ArrayList<ClientHandler> clients = new ArrayList<>();
    // to store usernames/passwords
    private static final ArrayList<String> usernames = new ArrayList<>();
    private static final ArrayList<String> passwords = new ArrayList<>();
    // to store reserved slots (to check availability)
    private static final ArrayList<String> reservedSlots = new ArrayList<>();
    
    static final Object LOCK = new Object();


    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(9090); // opens a server socket on port 9090
        System.out.println("Server started on port 9090");

        while (true) { // while socket port 9090 is open
            System.out.println("Waiting for client connection");
            Socket client = serverSocket.accept(); // waiting connection
            System.out.println("Connected to client");

            // new thread for new client
            ClientHandler clientThread =
                    new ClientHandler(client, clients, usernames, passwords, reservedSlots);

            clients.add(clientThread);
            new Thread(clientThread).start();
        }
    }
}
