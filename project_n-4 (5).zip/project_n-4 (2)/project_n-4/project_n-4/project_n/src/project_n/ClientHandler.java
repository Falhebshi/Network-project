/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project_n;

/**
 * ClientHandler: handles one connected client in its own thread.
 * - Performs a simple login/registration handshake.
 * - Accepts commands (LIST, RESERVE, quit).
 * - Shares reservation/state lists with other handlers via synchronized blocks.
 * 
 * Notes:
 * - All shared lists are passed in from the server and must be synchronized when accessed.
 * - Output is line-based; each println() sends a complete line to the client.
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

class ClientHandler implements Runnable {
    // The TCP connection for this client
    private final Socket client;
    // Reader for incoming text lines from the client
    private final BufferedReader in;
    // Writer for sending text lines to the client (auto-flush enabled)
    private final PrintWriter out;
    // Reference to the list of all active client handlers (shared)
    private final List<ClientHandler> clients;
    // Registered usernames (shared across clients)
    private final List<String> usernames;
    // Passwords aligned by index with 'usernames' (shared)
    private final List<String> passwords;
    // Reserved slots: each entry is "day|sport|time|field" (shared)
    private final List<String> reservedSlots; // day|sport|time|field

    /**
     * Construct a handler for one client socket and shared state.
     */
    public ClientHandler(Socket c, List<ClientHandler> clients, List<String> usernames,
                         List<String> passwords, List<String> reservedSlots) throws IOException {
        this.client = c;
        this.clients = clients;
        this.usernames = usernames;
        this.passwords = passwords;
        this.reservedSlots = reservedSlots;

        // Wrap the socket streams as line-based text I/O
        this.in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        this.out = new PrintWriter(client.getOutputStream(), true); // true = auto-flush on println
    }

    @Override
    public void run() {
        try {
            // ---- Login/registration handshake (expects 3 lines): username, password, logintype ----
            String username = in.readLine();
            String password = in.readLine();
            String logintype = in.readLine();

            // If any of the three are missing, abort
            if (username == null || password == null || logintype == null) {
                out.println("Invalid login handshake.");
                closeAndRemove();
                return;
            }

            // Register a new user
            if (logintype.equalsIgnoreCase("new")) {
                // Guard shared username/password lists
                synchronized (usernames) {
                    // Reject if username already taken
                    if (usernames.contains(username)) {
                        out.println("Username already exists! Please try again.");
                        closeAndRemove();
                        return;
                    }
                    // Append new username/password (indexes must stay aligned)
                    usernames.add(username);
                    passwords.add(password);
                }
                out.println("Registration successful! Welcome, " + username + "!");

            // Login for existing user
            } else if (logintype.equalsIgnoreCase("exist")) {
                boolean ok = false;
                synchronized (usernames) {
                    // Find username index and compare stored password
                    int idx = usernames.indexOf(username);
                    if (idx >= 0) {
                        String storedPass = passwords.get(idx);
                        ok = storedPass != null && storedPass.equals(password);
                    }
                }
                if (!ok) {
                    out.println("Invalid username or password.");
                    closeAndRemove();
                    return;
                }
                out.println("You are connected and logged in successfully.");

            // Client chose to quit at login stage
            } else if (logintype.equalsIgnoreCase("quit")) {
                out.println("Goodbye!");
                closeAndRemove();
                return;

            // Unknown login command
            } else {
                out.println("UNKNOWN LOGIN COMMAND");
                closeAndRemove();
                return;
            }

            // ---- Command loop (read one line at a time until null or 'quit') ----
            String line;
            while ((line = in.readLine()) != null) {
                String cmd = line.trim();

                // End session
                if (cmd.equalsIgnoreCase("quit")) {
                    out.println("Goodbye!");
                    break;
                }

                // LIST: send all reserved slots, one per line, then 'END'
                if (cmd.equalsIgnoreCase("LIST")) {
                    synchronized (reservedSlots) {
                        for (String key : reservedSlots) {
                            out.println(key);
                        }
                    }
                    out.println("END");
                    continue;
                }

                // RESERVE <Sport> <Day> <Time> <Field>
                if (cmd.toUpperCase().startsWith("RESERVE")) {
                    String[] parts = cmd.split("\\s+");
                    // Basic syntax check
                    if (parts.length < 5) {
                        out.println("REJECTED: Use RESERVE <Sport> <Day> <Time> <Field>");
                        continue;
                    }

                    // Read encoded tokens (client may send spaces as underscores)
                    String sportEnc = parts[1];
                    String dayEnc   = parts[2];
                    String timeEnc  = parts[3];
                    String fieldEnc = parts[4];

                    // Decode by replacing '_' with space for display/key
                    String sport = sportEnc.replace('_', ' ');
                    String day   = dayEnc.replace('_', ' ');
                    String time  = timeEnc.replace('_', ' ');
                    String field = fieldEnc.replace('_', ' ');

                    // Build the unique key for this slot
                    String slotKey = day + "|" + sport + "|" + time + "|" + field;

                    // Reserve if available; otherwise reject
                    synchronized (reservedSlots) {
                        if (reservedSlots.contains(slotKey)) {
                            out.println("REJECTED: Slot not available. Please choose another time/field.");
                        } else {
                            reservedSlots.add(slotKey);
                            out.println("CONFIRMED: " + slotKey);
                        }
                    }
                    continue;
                }

                // Any other command is not recognized
                out.println("UNKNOWN COMMAND");
            }

        } catch (IOException e) {
            // Reaching here typically means the client disconnected or I/O failed
            System.out.println("Client disconnected: " + e.getMessage());
        } finally {
            // Always remove this handler and close the socket
            closeAndRemove();
        }
    }

    /**
     * Close the client socket and remove this handler from the shared clients list.
     */
    private void closeAndRemove() {
        try { client.close(); } catch (IOException ignore) {}
        synchronized (clients) { clients.remove(this); }
    }
}