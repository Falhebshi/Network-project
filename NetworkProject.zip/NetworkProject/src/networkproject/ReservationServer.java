/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package networkproject;

/**
 *
 * @author memem
 */
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ReservationServer {
    // Synchronized lists for thread-safe operations
    static final List<ClientHandler> clients      = Collections.synchronizedList(new ArrayList<>());
    static final List<String> usernames           = Collections.synchronizedList(new ArrayList<>());
    static final List<String> passwords           = Collections.synchronizedList(new ArrayList<>());
    static final List<String> reservedSlots       = Collections.synchronizedList(new ArrayList<>()); // key: day|sport|time|field

    // Main server class that handles client connections and reservations
    public static void main(String[] args) throws IOException {
        try (ServerSocket serverSocket = new ServerSocket(9090)) {
            System.out.println("Server started on port 9090");
            while (true) {
                System.out.println("Waiting for client connection...");
                Socket client = serverSocket.accept();
                System.out.println("Connected to client");
                ClientHandler clientThread = new ClientHandler(client, clients, usernames, passwords, reservedSlots);
                clients.add(clientThread);
                new Thread(clientThread).start();
            }
        }
    }
}