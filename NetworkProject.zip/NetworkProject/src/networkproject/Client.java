package networkproject;

import javax.swing.*;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

public class Client {
    private static final String SERVER_IP = "localhost";
    private static final int SERVER_PORT = 9090;

    private static final String LOGO_PATH = "balltennis.png";
    private static final int LOGO_W = 28;
    private static final int LOGO_H = 28;

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;

    private JFrame frame;
    private JTextField tfUser;
    private JPasswordField pfPass;

    // === GUI: GradientPanel ===
    private static class GradientPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            int w = getWidth(), h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, new Color(66, 133, 244), 0, h, new Color(15, 157, 88));
            g2.setPaint(gp);
            g2.fillRect(0, 0, w, h);
            g2.dispose();
        }
    }

    // === MAIN ===
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Client().launchUI());
    }

    // === GUI: launchUI ===
    private void launchUI() {
        frame = new JFrame("Sportify Hub – Registration / Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(520, 340));
        frame.setLocationByPlatform(true);

        JPanel root = new GradientPanel();
        root.setLayout(new BorderLayout(16, 16));
        root.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel titleBar = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        titleBar.setOpaque(false);

        JLabel logo = new JLabel(loadScaledIcon(LOGO_PATH, LOGO_W, LOGO_H));
        if (logo.getIcon() == null) {
            logo.setPreferredSize(new Dimension(LOGO_W, LOGO_H));
        }

        JLabel title = new JLabel("Sportify Hub");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 22f));
        title.setForeground(Color.WHITE);

        titleBar.add(logo);
        titleBar.add(title);
        root.add(titleBar, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(8, 8, 8, 8);
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.anchor = GridBagConstraints.WEST;

        tfUser = new JTextField(20);
        pfPass = new JPasswordField(20);

        JLabel lu = new JLabel("Username");
        JLabel lp = new JLabel("Password");
        lu.setForeground(Color.WHITE);
        lp.setForeground(Color.WHITE);

        gc.gridx = 0; gc.gridy = 0; form.add(lu, gc);
        gc.gridx = 1; gc.gridy = 0; form.add(tfUser, gc);
        gc.gridx = 0; gc.gridy = 1; form.add(lp, gc);
        gc.gridx = 1; gc.gridy = 1; form.add(pfPass, gc);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 0));
        buttons.setOpaque(false);

        JButton btnRegister = new JButton("Register");
        JButton btnLogin   = new JButton("Login");
        styleBlue(btnRegister);
        styleBlue(btnLogin);

        buttons.add(btnRegister);
        buttons.add(btnLogin);

        gc.gridx = 0;
        gc.gridy = 2;
        gc.gridwidth = 2;
        gc.anchor = GridBagConstraints.CENTER;
        form.add(buttons, gc);

        gc.gridwidth = 1;
        gc.anchor = GridBagConstraints.WEST;

        root.add(form, BorderLayout.CENTER);

        btnRegister.addActionListener(this::onRegister);

        frame.setContentPane(root);
        frame.pack();
        frame.setVisible(true);

        frame.addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                safeQuitAndClose();
            }
        });
    }

    // === UI STYLE: styleBlue ===
    private static void styleBlue(JButton b) {
        b.setFont(new Font("Arial", Font.BOLD, 13));
        b.setPreferredSize(new Dimension(110, 36));
        b.setForeground(Color.WHITE);
        b.setBackground(new Color(66, 133, 244));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setContentAreaFilled(false);
        b.setOpaque(false);

        b.setUI(new BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = c.getWidth();
                int h = c.getHeight();
                int arc = 24;

                g2.setColor(b.getBackground());
                g2.fillRoundRect(0, 0, w, h, arc, arc);

                g2.setColor(new Color(36, 93, 204));
                g2.setStroke(new BasicStroke(2f));
                g2.drawRoundRect(1, 1, w - 3, h - 3, arc, arc);

                String text = b.getText();
                FontMetrics fm = g2.getFontMetrics();
                int textW = fm.stringWidth(text);
                int textH = fm.getAscent();
                g2.setColor(b.getForeground());
                g2.drawString(text, (w - textW) / 2, (h + textH) / 2 - 2);

                g2.dispose();
            }
        });

        b.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                b.setBackground(new Color(36, 93, 204));
                b.repaint();
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                b.setBackground(new Color(66, 133, 244));
                b.repaint();
            }
        });
    }

    // === UI HELPERS: makeLabeledBox ===
    private static JPanel makeLabeledBox(String label, JComponent field) {
        JLabel l = new JLabel(label);
        l.setForeground(Color.WHITE);
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(l);
        p.add(Box.createVerticalStrut(4));
        p.add(field);
        return p;
    }

    // === UI STYLE: styleComboMini ===
    private static <T> void styleComboMini(JComboBox<T> cb) {
        Dimension sz = new Dimension(160, 26);
        cb.setFont(new Font("Arial", Font.PLAIN, 12));
        cb.setPreferredSize(sz);
        cb.setMaximumSize(sz);
        cb.setMinimumSize(sz);
        cb.setBackground(new Color(66,133,244));
        cb.setForeground(Color.WHITE);
        cb.setOpaque(true);

        cb.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (isSelected) {
                    setBackground(new Color(36,93,204));
                    setForeground(Color.WHITE);
                } else {
                    setBackground(new Color(66,133,244));
                    setForeground(Color.WHITE);
                }
                return c;
            }
        });
    }

    // === AUTH: authPersistent ===
    private String authPersistent(String username, String password, boolean isRegistration) throws IOException {
        if (socket == null || socket.isClosed()) {
            socket = new Socket(SERVER_IP, SERVER_PORT);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
        }
        out.println(username);
        out.println(password);
        out.println(isRegistration ? "new" : "exist");
        return in.readLine();
    }

    // === SESSION: safeQuitAndClose ===
    private void safeQuitAndClose() {
        try {
            if (out != null) { out.println("quit"); out.flush(); }
        } catch (Exception ignored) {}
        try {
            if (socket != null) socket.close();
        } catch (Exception ignored) {}
    }

    // === AUTH: interpretAuthReply ===
    private String interpretAuthReply(String resp, boolean isRegistration) {
        if (resp == null) return "no_response";
        String r = resp.trim().toLowerCase();

        if (r.contains("success")) return "success";

        if (
            r.contains("does not exist") ||
            r.contains("not exist") ||
            r.contains("user not found") ||
            r.contains("username not found") ||
            r.contains("no such user") ||
            r.contains("no account") ||
            r.contains("unregistered") ||
            r.contains("not registered") ||
            r.contains("unknown user") ||
            r.contains("unknown username") ||
            r.contains("invalid username") ||
            r.contains("bad username")
        ) {
            return "user_not_found";
        }

        if (
            r.contains("wrong password") ||
            r.contains("incorrect password") ||
            r.contains("invalid password") ||
            r.contains("bad password") ||
            r.contains("password mismatch") ||
            r.contains("invalid credentials") ||
            r.contains("incorrect credentials")
        ) {
            return "wrong_password";
        }

        if (r.contains("already logged in") || r.contains("active session")) {
            return "already_logged_in";
        }

        if (isRegistration) {
            if (r.contains("exists") || r.contains("already used") || r.contains("taken")) {
                return "fail";
            }
        }

        return "fail";
    }

    // === ACTION: onRegister ===
    private void onRegister(ActionEvent e) {
        String u = tfUser.getText().trim();
        String p = new String(pfPass.getPassword());
        if (u.isEmpty() || p.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter both username and password.", "Missing Fields", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            String resp = authPersistent(u, p, true);
            String verdict = interpretAuthReply(resp, true);

            if ("success".equals(verdict)) {
                JOptionPane.showMessageDialog(frame,
                        "Registration successful, welcome " + u + " !",
                        "Sportify Hub", JOptionPane.INFORMATION_MESSAGE);
                openReservationWindow(u);
            } else if ("fail".equals(verdict)) {
                JOptionPane.showMessageDialog(frame,
                        (resp == null ? "Registration failed." : resp),
                        "Registration", JOptionPane.WARNING_MESSAGE);
                safeQuitAndClose();
            } else if ("no_response".equals(verdict)) {
                JOptionPane.showMessageDialog(frame, "No response from server.", "Registration", JOptionPane.WARNING_MESSAGE);
                safeQuitAndClose();
            } else {
                JOptionPane.showMessageDialog(frame,
                        (resp == null ? "Registration failed." : resp),
                        "Registration", JOptionPane.WARNING_MESSAGE);
                safeQuitAndClose();
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame, "Connection error: " + ex.getMessage(),
                    "Registration", JOptionPane.ERROR_MESSAGE);
            safeQuitAndClose();
        }
    }

    

    // === GUI: openReservationWindow ===
    private void openReservationWindow(String username) {
        JFrame reserveFrame = new JFrame("Make a Reservation");
        reserveFrame.setSize(560, 420);
        reserveFrame.setLocationRelativeTo(frame);
        reserveFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        if (frame != null) frame.setVisible(false);

        JPanel root = new GradientPanel();
        root.setLayout(new BorderLayout(16, 16));
        root.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel titleBar = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        titleBar.setOpaque(false);
        JLabel logo = new JLabel(loadScaledIcon(LOGO_PATH, LOGO_W, LOGO_H));
        if (logo.getIcon() == null) logo.setPreferredSize(new Dimension(LOGO_W, LOGO_H));
        JLabel title = new JLabel("Ready to book your spot?");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(Color.WHITE);
        titleBar.add(logo);
        titleBar.add(title);
        root.add(titleBar, BorderLayout.NORTH);

        JComboBox<String> cbDate  = new JComboBox<>();
        JComboBox<String> cbSport = new JComboBox<>();
        JComboBox<String> cbTime  = new JComboBox<>();
        JComboBox<String> cbField = new JComboBox<>();
        styleComboMini(cbDate);
        styleComboMini(cbSport);
        styleComboMini(cbTime);
        styleComboMini(cbField);

        JPanel grid = new JPanel(new GridBagLayout());
        grid.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(10, 10, 10, 10);
        g.anchor = GridBagConstraints.NORTHWEST;
        g.fill = GridBagConstraints.NONE;
        g.weightx = 0; g.weighty = 0;

        g.gridx = 0; g.gridy = 0; grid.add(makeLabeledBox("Date:",  cbDate), g);
        g.gridx = 1; g.gridy = 0; grid.add(makeLabeledBox("Sport:", cbSport), g);
        g.gridx = 0; g.gridy = 1; grid.add(makeLabeledBox("Time:",  cbTime), g);
        g.gridx = 1; g.gridy = 1; grid.add(makeLabeledBox("Field:", cbField), g);

        JButton btnBook = new JButton("Book Now");
        styleBlue(btnBook);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 0));
        actions.setOpaque(false);
        actions.add(btnBook);

        root.add(grid, BorderLayout.CENTER);
        root.add(actions, BorderLayout.SOUTH);
        reserveFrame.setContentPane(root);

        Runnable setDefaultValues = () -> {
            try {
                Set<String> reserved = fetchReservations();

                if (cbDate.getItemCount() == 0) {
                    cbDate.removeAllItems();
                    for (String d : AddNewReservations.computeAvailableDates(reserved)) {
                        cbDate.addItem(d);
                    }
                }
                if (cbDate.getItemCount() > 0 && cbDate.getSelectedItem() == null) {
                    cbDate.setSelectedIndex(0);
                }

                String currentDate = (String) cbDate.getSelectedItem();
                if (currentDate != null && cbSport.getItemCount() == 0) {
                    cbSport.removeAllItems();
                    for (String s : AddNewReservations.computeAvailableSports(currentDate, reserved)) {
                        cbSport.addItem(s);
                    }
                }
                if (cbSport.getItemCount() > 0 && cbSport.getSelectedItem() == null) {
                    cbSport.setSelectedIndex(0);
                }

                String currentSport = (String) cbSport.getSelectedItem();
                if (currentDate != null && currentSport != null && cbTime.getItemCount() == 0) {
                    cbTime.removeAllItems();
                    for (String t : AddNewReservations.computeAvailableTimes(currentDate, currentSport, reserved)) {
                        cbTime.addItem(t);
                    }
                }
                if (cbTime.getItemCount() > 0 && cbTime.getSelectedItem() == null) {
                    cbTime.setSelectedIndex(0);
                }

                String currentTime = (String) cbTime.getSelectedItem();
                if (currentDate != null && currentSport != null && currentTime != null && cbField.getItemCount() == 0) {
                    cbField.removeAllItems();
                    for (String f : AddNewReservations.computeAvailableFields(currentDate, currentSport, currentTime, reserved)) {
                        cbField.addItem(f);
                    }
                }
                if (cbField.getItemCount() > 0 && cbField.getSelectedItem() == null) {
                    cbField.setSelectedIndex(0);
                }

            } catch (IOException ex) {
                showConnErr(reserveFrame, ex);
            }
        };

        setDefaultValues.run();

        cbDate.addActionListener(e -> {
            cbSport.removeAllItems();
            cbTime.removeAllItems();
            cbField.removeAllItems();
            setDefaultValues.run();
        });

        cbSport.addActionListener(e -> {
            cbTime.removeAllItems();
            cbField.removeAllItems();
            setDefaultValues.run();
        });

        cbTime.addActionListener(e -> {
            cbField.removeAllItems();
            setDefaultValues.run();
        });

        btnBook.addActionListener(e -> {
            String date  = (String) cbDate.getSelectedItem();
            String sport = (String) cbSport.getSelectedItem();
            String time  = (String) cbTime.getSelectedItem();
            String field = (String) cbField.getSelectedItem();

            if (date != null && sport != null && time != null && field != null) {
                int confirm = JOptionPane.showConfirmDialog(
                        reserveFrame,
                        "Confirm reservation?\n\nDate: " + date + "\nSport: " + sport + "\nTime: " + time + "\nField: " + field,
                        "Confirm Reservation", JOptionPane.YES_NO_OPTION
                );
                if (confirm != JOptionPane.YES_OPTION) return;

                try {
                    String resp = sendReserve(sport, date, time, field);
                    if (resp != null && resp.startsWith("CONFIRMED")) {
                        JOptionPane.showMessageDialog(reserveFrame, "Reservation confirmed!\n" + resp);

                        reserveFrame.dispose();
                        safeQuitAndClose();

                        if (tfUser != null) tfUser.setText("");
                        if (pfPass != null) pfPass.setText("");

                        if (frame != null) {
                            frame.setVisible(true);
                            frame.toFront();
                            frame.requestFocus();
                        }
                    } else {
                        JOptionPane.showMessageDialog(reserveFrame, (resp == null ? "No response from server." : resp),
                                                      "Reservation", JOptionPane.WARNING_MESSAGE);
                    }
                } catch (IOException ex) {
                    showConnErr(reserveFrame, ex);
                }
            } else {
                JOptionPane.showMessageDialog(reserveFrame, "Please wait for default values to load.", "Warning", JOptionPane.WARNING_MESSAGE);
            }
        });

        reserveFrame.setVisible(true);
    }

    // === UI: showConnErr ===
    private void showConnErr(Component parent, IOException ex) {
        JOptionPane.showMessageDialog(parent, "Connection error: " + ex.getMessage(), "Network", JOptionPane.ERROR_MESSAGE);
    }

    // === SERVER: fetchReservations ===
    private Set<String> fetchReservations() throws IOException {
        ensureConnected();
        out.println("LIST");
        out.flush();

        Set<String> keys = new HashSet<>();
        String line;
        while ((line = in.readLine()) != null) {
            if ("END".equals(line)) break;
            if (!line.trim().isEmpty()) keys.add(line.trim());
        }
        return keys;
    }

    // === SERVER: sendReserve ===
    private String sendReserve(String sport, String day, String time, String field) throws IOException {
        ensureConnected();
        String s = sport.replace(' ', '_');
        String d = day.replace(' ', '_');
        String t = time.replace(' ', '_');
        String f = field.replace(' ', '_');
        out.println("RESERVE " + s + " " + d + " " + t + " " + f);
        out.flush();
        return in.readLine();
    }

    // === NET: ensureConnected ===
    private void ensureConnected() throws IOException {
        if (socket == null || socket.isClosed()) {
            socket = new Socket(SERVER_IP, SERVER_PORT);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
        }
    }

    // === IMAGE: loadScaledIcon ===
    private static ImageIcon loadScaledIcon(String path, int w, int h) {
        try {
            URL url = Client.class.getResource(path);
            Image img;
            if (url != null) {
                img = new ImageIcon(url).getImage();
            } else {
                img = new ImageIcon(path).getImage();
            }
            if (img == null) return null;
            Image scaled = img.getScaledInstance(w, h, Image.SCALE_SMOOTH);
            return new ImageIcon(scaled);
        } catch (Exception ignored) {
            return null;
        }
    }
}
