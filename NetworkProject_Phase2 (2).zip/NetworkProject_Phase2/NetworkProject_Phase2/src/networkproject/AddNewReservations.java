package networkproject;


import java.util.Scanner;
import java.util.ArrayList;

public class AddNewReservations {
    public static final String[] DATES = {
        "",//so we can start from index 1 instead of 0
        "2025-09-06",
        "2025-09-07",
        "2025-09-08",
        "2025-09-09",
        "2025-09-10",
        "2025-09-11",
        "2025-09-12"
    }; //all dates that can be reservied

    public static final String[] SPORTS = { "", "Padel", "Tennis", "Football" }; //all sports that can be reservied
    public static final String[] FIELDS = { "", "Field 1", "Field 2", "Field 3", "Field 4", "Field 5" };//all fields that can be reservied
    public static final String[] TIMES = {
        "",//so we can start from index 1 instead of 0
        "08:00 - 09:00",
        "09:00 - 10:00",
        "10:00 - 11:00",
        "17:00 - 18:00",
        "18:00 - 19:00",
        "19:00 - 20:00"
    };//all times that can be reservied

    public static String formatDate(String dateValue) { //display date
        if (dateValue == null || dateValue.length() < 10) return dateValue; //if date value isn't valid
        String year = dateValue.substring(0, 4);//cut year
        int month = Integer.parseInt(dateValue.substring(5, 7));//cut month
        int day = Integer.parseInt(dateValue.substring(8, 10));//cut day
        return day + " " + monthName(month) + " " + year;
    }

    public static String monthName(int m) {//get the month name from the month number
        String[] names = {"", "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        return (m >= 1 && m <= 12) ? names[m] : String.valueOf(m);
    }

    public static ArrayList<String> computeAvailableDates(java.util.Set<String> reservedKeys) {
/* an arraylist that dose not allow replicate+
reservedKeys is attribute coming from the server containing all reservation*/
        ArrayList<String> result = new ArrayList<>();
        for (int i = 1; i < DATES.length; i++) {
            String d = DATES[i];
            if (isDateAvailable(d, reservedKeys))  //check if the date is available
                result.add(d);// if the date is available it will be added to the array of available dates
           
        }
        return result;// return available dates
    }

    public static ArrayList<String> computeAvailableSports(String date, java.util.Set<String> reservedKeys) {
        /* an arraylist that dose not allow replicate+
reservedKeys is attribute coming from the server containing all reservation*/
        ArrayList<String> list = new ArrayList<>();
        if (date == null) //date is not valid
            return list;
        for (int i = 1; i < SPORTS.length; i++) {
            String sport = SPORTS[i];
            if (isSportAvailable(date, sport, reservedKeys)) //check if the sport is available
                list.add(sport);// if the sport is available it will be added to the array of available sports
        }
        return list; //return availabel sports
    }

    public static ArrayList<String> computeAvailableTimes(String date, String sport, java.util.Set<String> reservedKeys) {
        /* an arraylist that dose not allow replicate+
reservedKeys is attribute coming from the server containing all reservation*/
        ArrayList<String> list = new ArrayList<>();
        if (date == null || sport == null)// date or/and sport is not valid
            return list;
        for (int i = 1; i < TIMES.length; i++) {
            String time = TIMES[i];
            if (hasAnyFieldFree(date, sport, time, reservedKeys))
                //check if the date,sport,time is available
                list.add(time);// if the time is available it will be added to the array of available timess
        }
        return list;//return availabel times
    }

    public static ArrayList<String> computeAvailableFields(String date, String sport, String time, java.util.Set<String> reservedKeys) {
        /* an arraylist that dose not allow replicate+
reservedKeys is attribute coming from the server containing all reservation*/
        ArrayList<String> list = new ArrayList<>();
        if (date == null || sport == null || time == null)// date or/and sport or/and time is not valid
            return list;
        for (int i = 1; i < FIELDS.length; i++) {
            String field = FIELDS[i];
            String key = date + "|" + sport + "|" + time + "|" + field;
            if (!reservedKeys.contains(key))// check if there is any available fields
                list.add(field);// if the field is available it will be added to the array of available fields
        }
        return list;//return availabel fields
    }

    // --- internal helpers ---
    private static boolean isDateAvailable(String date, java.util.Set<String> reservedKeys) {
        /* an arraylist that dose not allow replicate+
reservedKeys is attribute coming from the server containing all reservation*/
        for (int i = 1; i < SPORTS.length; i++) {
            if (isSportAvailable(date, SPORTS[i], reservedKeys)) //check if there is any available sport in that date  
                return true;
        }
        return false;
    }

    private static boolean isSportAvailable(String date, String sport, java.util.Set<String> reservedKeys) {
         /* an arraylist that dose not allow replicate+
reservedKeys is attribute coming from the server containing all reservation*/
        for (int i = 1; i < TIMES.length; i++) {
            if (hasAnyFieldFree(date, sport, TIMES[i], reservedKeys))//check if there is any available time in that sport  
                return true;
        }
        return false;
    }

    private static boolean hasAnyFieldFree(String date, String sport, String time, java.util.Set<String> reservedKeys) {
        /* an arraylist that dose not allow replicate+
reservedKeys is attribute coming from the server containing all reservation*/
        int taken = 0;
        int totalFields = FIELDS.length - 1;//actual total fiels without the empty element
        for (int i = 1; i < FIELDS.length; i++) {
            String key = date + "|" + sport + "|" + time + "|" + FIELDS[i];
            if (reservedKeys.contains(key))
                taken++;
        }
        return taken < totalFields;// if taken>5 there is no available fields
    }
}