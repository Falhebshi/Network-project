/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package networkproject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

class ClientHandler implements Runnable {

    // The TCP connection for this client
    private final Socket client;
    // Reader for incoming text lines from the client
    private final BufferedReader in;
    // Writer for sending text lines to the client (auto-flush enabled)
    private final PrintWriter out;
    // Reference to the list of all active client handlers (shared)
    private final List<ClientHandler> clients;
    // Registered usernames (shared across clients)
    private final List<String> usernames;
    // Passwords aligned by index with 'usernames' (shared)
    private final List<String> passwords;
    // Reserved slots: each entry is "day|sport|time|field" (shared)
    private final List<String> reservedSlots; // day|sport|time|field

    private String username; // <== NEW: logged-in user for this handler

    /**
     * Construct a handler for one client socket and shared state.
     */
    public ClientHandler(Socket c, List<ClientHandler> clients, List<String> usernames,
            List<String> passwords, List<String> reservedSlots) throws IOException {
        this.client = c;
        this.clients = clients;
        this.usernames = usernames;
        this.passwords = passwords;
        this.reservedSlots = reservedSlots;

        // Wrap the socket streams as line-based text I/O
        this.in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        this.out = new PrintWriter(client.getOutputStream(), true); // true = auto-flush on println
    }

    @Override
    public void run() {
        try {
            // ---- Login/registration handshake (expects 3 lines): username, password, logintype ----
            String username = in.readLine();
            String password = in.readLine();
            String logintype = in.readLine();

            // If any of the three are missing, abort
            if (username == null || password == null || logintype == null) {
                out.println("Invalid login handshake.");
                closeAndRemove();
                return;
            }

            // ---------- REGISTRATION ----------
            if (logintype.equalsIgnoreCase("new")) {
                synchronized (usernames) {
                    if (usernames.contains(username)) {
                        out.println("Username already exists! Please try again.");
                        closeAndRemove();
                        return;
                    }
                    // add new user
                    usernames.add(username);
                    passwords.add(password);
                }
                this.username = username;
                out.println("Registration successful! Welcome, " + username + "!");

                // ---------- LOGIN ----------
            } else if (logintype.equalsIgnoreCase("exist")) {
                boolean ok = false;
                synchronized (usernames) {
                    int idx = usernames.indexOf(username);
                    if (idx >= 0) {
                        String storedPass = passwords.get(idx);
                        ok = storedPass != null && storedPass.equals(password);
                    }
                }
                if (!ok) {
                    out.println("Invalid username or password.");
                    closeAndRemove();
                    return;
                }
                this.username = username;
                out.println("You are connected and logged in successfully.");

                // ---------- QUIT AT LOGIN STAGE ----------
            } else if (logintype.equalsIgnoreCase("quit")) {
                out.println("Goodbye!");
                closeAndRemove();
                return;

                // ---------- UNKNOWN LOGIN COMMAND ----------
            } else {
                out.println("UNKNOWN LOGIN COMMAND");
                closeAndRemove();
                return;
            }

            // =================== COMMAND LOOP ===================
            String line;
            while ((line = in.readLine()) != null) {
                String cmd = line.trim();
                if (cmd.isEmpty()) {
                    continue; // ignore blank lines
                }

                // -------- quit --------
                if (cmd.equalsIgnoreCase("quit")) {
                    out.println("Goodbye!");
                    break;
                } // -------- LIST: send all reserved slots (without username) --------
                else if (cmd.equalsIgnoreCase("LIST")) {
                    synchronized (reservedSlots) {
                        for (String s : reservedSlots) {
                            // s = username|day|sport|time|field
                            String[] p = s.split("\\|", 5);
                            if (p.length == 5) {
                                String publicKey = p[1] + "|" + p[2] + "|" + p[3] + "|" + p[4];
                                out.println(publicKey);
                            }
                        }
                    }
                    out.println("END");
                } // -------- RESERVE <Sport> <Day> <Time> <Field> --------
                else if (cmd.toUpperCase().startsWith("RESERVE")) {
                    String[] parts = cmd.split("\\s+");
                    if (parts.length < 5) {
                        out.println("REJECTED: Use RESERVE <Sport> <Day> <Time> <Field>");
                        continue;
                    }

                    String sport = parts[1].replace('_', ' ');
                    String day = parts[2].replace('_', ' ');
                    String time = parts[3].replace('_', ' ');
                    String field = parts[4].replace('_', ' ');

                    // What the client sees (no username)
                    String publicKey = day + "|" + sport + "|" + time + "|" + field;
                    // What we store
                    String storedKey = this.username + "|" + publicKey;

                    boolean taken = false;
                    synchronized (reservedSlots) {
                        for (String s : reservedSlots) {
                            String[] p = s.split("\\|", 5);
                            if (p.length == 5) {
                                String existingPublic
                                        = p[1] + "|" + p[2] + "|" + p[3] + "|" + p[4];
                                if (existingPublic.equals(publicKey)) {
                                    taken = true;
                                    break;
                                }
                            }
                        }

                        if (taken) {
                            out.println("REJECTED: Slot not available. Please choose another time/field.");
                        } else {
                            reservedSlots.add(storedKey);
                            out.println("CONFIRMED: " + publicKey);
                        }
                    }
                } // -------- MYBOOKINGS (only current user's bookings) --------
                else if (cmd.equalsIgnoreCase("MYBOOKINGS")) {
                    synchronized (reservedSlots) {
                        for (String s : reservedSlots) {
                            // s = username|day|sport|time|field
                            String[] p = s.split("\\|", 5);
                            if (p.length == 5 && p[0].equals(this.username)) {
                                String publicKey = p[1] + "|" + p[2] + "|" + p[3] + "|" + p[4];
                                out.println(publicKey);
                            }
                        }
                    }
                    out.println("END");
                } // -------- CANCEL <Sport> <Day> <Time> <Field> --------
                else if (cmd.toUpperCase().startsWith("CANCEL")) {
                    String[] parts = cmd.split("\\s+");
                    if (parts.length < 5) {
                        out.println("ERROR: Invalid CANCEL command.");
                        continue;
                    }

                    String sport = parts[1].replace('_', ' ');
                    String day = parts[2].replace('_', ' ');
                    String time = parts[3].replace('_', ' ');
                    String field = parts[4].replace('_', ' ');

                    String publicKey = day + "|" + sport + "|" + time + "|" + field;

                    boolean removed = false;
                    synchronized (reservedSlots) {
                        for (int i = 0; i < reservedSlots.size(); i++) {
                            String s = reservedSlots.get(i);  // username|day|sport|time|field
                            String[] p = s.split("\\|", 5);
                            if (p.length == 5) {
                                String existingPublic
                                        = p[1] + "|" + p[2] + "|" + p[3] + "|" + p[4];
                                if (p[0].equals(this.username) && existingPublic.equals(publicKey)) {
                                    reservedSlots.remove(i);
                                    removed = true;
                                    break;
                                }
                            }
                        }
                    }

                    if (removed) {
                        out.println("CANCELLED: " + publicKey);
                    } else {
                        out.println("NOT_FOUND: You don’t have this reservation.");
                    }
                } // -------- anything else --------
                else {
                    out.println("UNKNOWN COMMAND");
                }
            }

        } catch (IOException e) {
            System.out.println("Client disconnected: " + e.getMessage());
        } finally {
            // Always remove this handler and close the socket
            closeAndRemove();
        }
    }

    /**
     * Close the client socket and remove this handler from the shared clients
     * list.
     */
    private void closeAndRemove() {
        try {
            client.close();
        } catch (IOException ignore) {
        }
        synchronized (clients) {
            clients.remove(this);
        }
    }
}
