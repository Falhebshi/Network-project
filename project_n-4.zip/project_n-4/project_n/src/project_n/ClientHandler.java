/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project_n;

/**
 *
 * @author memem
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

class ClientHandler implements Runnable {
    private final Socket client;
    private final BufferedReader in;
    private final PrintWriter out;
    private final List<ClientHandler> clients;
    private final List<String> usernames;
    private final List<String> passwords;
    private final List<String> reservedSlots; // day|sport|time|field

    public ClientHandler(Socket c, List<ClientHandler> clients, List<String> usernames,
                         List<String> passwords, List<String> reservedSlots) throws IOException {
        this.client = c;
        this.clients = clients;
        this.usernames = usernames;
        this.passwords = passwords;
        this.reservedSlots = reservedSlots;

        this.in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        this.out = new PrintWriter(client.getOutputStream(), true);
    }

    @Override
    public void run() {
        try {
            // --- مصافحة تسجيل الدخول ---
            String username = in.readLine();
            String password = in.readLine();
            String logintype = in.readLine();

            if (username == null || password == null || logintype == null) {
                out.println("Invalid login handshake.");
                closeAndRemove();
                return;
            }

            if (logintype.equalsIgnoreCase("new")) {
                synchronized (usernames) {
                    if (usernames.contains(username)) {
                        out.println("Username already exists! Please try again.");
                        closeAndRemove();
                        return;
                    }
                    usernames.add(username);
                    passwords.add(password);
                }
                out.println("Registration successful! Welcome, " + username + "!");

            } else if (logintype.equalsIgnoreCase("exist")) {
                boolean ok = false;
                synchronized (usernames) {
                    int idx = usernames.indexOf(username);
                    if (idx >= 0) {
                        String storedPass = passwords.get(idx);
                        ok = storedPass != null && storedPass.equals(password);
                    }
                }
                if (!ok) {
                    out.println("Invalid username or password.");
                    closeAndRemove();
                    return;
                }
                out.println("You are connected and logged in successfully.");

            } else if (logintype.equalsIgnoreCase("quit")) {
                out.println("Goodbye!");
                closeAndRemove();
                return;
            } else {
                out.println("UNKNOWN LOGIN COMMAND");
                closeAndRemove();
                return;
            }

            // --- لوب الأوامر ---
            String line;
            while ((line = in.readLine()) != null) {
                String cmd = line.trim();

                if (cmd.equalsIgnoreCase("quit")) {
                    out.println("Goodbye!");
                    break;
                }

                // يعيد كل الحجوزات سطرًا سطرًا وينهي بـ END
                if (cmd.equalsIgnoreCase("LIST")) {
                    synchronized (reservedSlots) {
                        for (String key : reservedSlots) {
                            out.println(key);
                        }
                    }
                    out.println("END");
                    continue;
                }

                // RESERVE <Sport> <Day> <Time> <Field>
                if (cmd.toUpperCase().startsWith("RESERVE")) {
                    String[] parts = cmd.split("\\s+");
                    if (parts.length < 5) {
                        out.println("REJECTED: Use RESERVE <Sport> <Day> <Time> <Field>");
                        continue;
                    }

                    String sportEnc = parts[1];
                    String dayEnc   = parts[2];
                    String timeEnc  = parts[3];
                    String fieldEnc = parts[4];

                    // فك الترميز (استبدال _ بفراغ)
                    String sport = sportEnc.replace('_', ' ');
                    String day   = dayEnc.replace('_', ' ');
                    String time  = timeEnc.replace('_', ' ');
                    String field = fieldEnc.replace('_', ' ');

                    String slotKey = day + "|" + sport + "|" + time + "|" + field;

                    synchronized (reservedSlots) {
                        if (reservedSlots.contains(slotKey)) {
                            out.println("REJECTED: Slot not available. Please choose another time/field.");
                        } else {
                            reservedSlots.add(slotKey);
                            out.println("CONFIRMED: " + slotKey);
                        }
                    }
                    continue;
                }

                out.println("UNKNOWN COMMAND");
            }

        } catch (IOException e) {
            System.out.println("Client disconnected: " + e.getMessage());
        } finally {
            closeAndRemove();
        }
    }

    private void closeAndRemove() {
        try { client.close(); } catch (IOException ignore) {}
        synchronized (clients) { clients.remove(this); }
    }
}
