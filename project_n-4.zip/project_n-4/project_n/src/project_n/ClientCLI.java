/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project_n;

/**
 *
 * @author memem
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class ClientCLI {
    private static final String SERVER_IP = "localhost";
    private static final int SERVER_PORT = 9094;

    // Persistent session
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;

    // ---------- GUI fields ----------
    private JFrame frame;
    private JTextField tfUser;
    private JPasswordField pfPass;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ClientCLI().launchUI());
    }

    private void launchUI() {
        frame = new JFrame("Sportify Hub – Registration / Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(480, 300));
        frame.setLocationByPlatform(true);

        JPanel root = new JPanel(new BorderLayout(16, 16));
        root.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JLabel title = new JLabel("Welcome to Sportify Hub");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 20f));
        root.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(8, 8, 8, 8);
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.anchor = GridBagConstraints.WEST;

        tfUser = new JTextField(20);
        pfPass = new JPasswordField(20);

        gc.gridx = 0; gc.gridy = 0; form.add(new JLabel("Username"), gc);
        gc.gridx = 1; gc.gridy = 0; form.add(tfUser, gc);
        gc.gridx = 0; gc.gridy = 1; form.add(new JLabel("Password"), gc);
        gc.gridx = 1; gc.gridy = 1; form.add(pfPass, gc);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        JButton btnRegister = new JButton("Register");
        JButton btnLogin = new JButton("Login");
        buttons.add(btnRegister);
        buttons.add(btnLogin);

        gc.gridx = 1; gc.gridy = 2; form.add(buttons, gc);
        root.add(form, BorderLayout.CENTER);

        btnRegister.addActionListener(this::onRegister);
        btnLogin.addActionListener(this::onLogin);

        frame.setContentPane(root);
        frame.pack();
        frame.setVisible(true);

        frame.addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                safeQuitAndClose();
            }
        });
    }

    // =========================
    //     Auth + Session
    // =========================
    private String authPersistent(String username, String password, boolean isRegistration) throws IOException {
        // إعادة استخدام جلسة قديمة لو موجودة
        if (socket == null || socket.isClosed()) {
            socket = new Socket(SERVER_IP, SERVER_PORT);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
        }

        out.println(username);
        out.println(password);
        out.println(isRegistration ? "new" : "exist");
        return in.readLine(); // أول سطر رد
    }

    private void safeQuitAndClose() {
        try {
            if (out != null) { out.println("quit"); out.flush(); }
        } catch (Exception ignored) {}
        try {
            if (socket != null) socket.close();
        } catch (Exception ignored) {}
    }

    // =========================
    //        Actions
    // =========================
    private void onRegister(ActionEvent e) {
        String u = tfUser.getText().trim();
        String p = new String(pfPass.getPassword());
        if (u.isEmpty() || p.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter both username and password.", "Missing Fields", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            String resp = authPersistent(u, p, true);
            if (resp != null && resp.toLowerCase().contains("successful")) {
                JOptionPane.showMessageDialog(frame, "Registration successful!", "Sportify Hub", JOptionPane.INFORMATION_MESSAGE);
                openReservationWindow(u);
            } else {
                JOptionPane.showMessageDialog(frame, (resp == null ? "No response from server." : resp), "Registration", JOptionPane.WARNING_MESSAGE);
                safeQuitAndClose();
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame, "Connection error: " + ex.getMessage(), "Registration", JOptionPane.ERROR_MESSAGE);
            safeQuitAndClose();
        }
    }

    private void onLogin(ActionEvent e) {
        String u = tfUser.getText().trim();
        String p = new String(pfPass.getPassword());
        if (u.isEmpty() || p.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter both username and password.", "Missing Fields", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            String resp = authPersistent(u, p, false);
            if (resp != null && resp.toLowerCase().contains("logged in successfully")) {
                JOptionPane.showMessageDialog(frame, "Login successful!", "Sportify Hub", JOptionPane.INFORMATION_MESSAGE);
                openReservationWindow(u);
            } else {
                JOptionPane.showMessageDialog(frame, (resp == null ? "No response from server." : resp), "Login", JOptionPane.WARNING_MESSAGE);
                safeQuitAndClose();
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame, "Connection error: " + ex.getMessage(), "Login", JOptionPane.ERROR_MESSAGE);
            safeQuitAndClose();
        }
    }

    // =========================
    //   Reservation Window
    // =========================
    private void openReservationWindow(String username) {
        JFrame reserveFrame = new JFrame("Make a Reservation");
        reserveFrame.setSize(460, 340);
        reserveFrame.setLocationRelativeTo(frame);
        reserveFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lblDate = new JLabel("Date:");
        JLabel lblSport = new JLabel("Sport:");
        JLabel lblTime = new JLabel("Time:");
        JLabel lblField = new JLabel("Field:");
        JButton btnRefresh = new JButton("Refresh");
        JButton btnBook = new JButton("Book Now");

        JComboBox<String> cbDate = new JComboBox<>();
        JComboBox<String> cbSport = new JComboBox<>();
        JComboBox<String> cbTime = new JComboBox<>();
        JComboBox<String> cbField = new JComboBox<>();

        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.add(lblDate);  panel.add(cbDate);
        panel.add(lblSport); panel.add(cbSport);
        panel.add(lblTime);  panel.add(cbTime);
        panel.add(lblField); panel.add(cbField);
        panel.add(btnRefresh); panel.add(btnBook);

        reserveFrame.add(panel);

        // helpers
        Runnable refillDates = () -> {
            try {
                Set<String> reserved = fetchReservations();
                cbDate.removeAllItems();
                for (String d : AddNewReservations.computeAvailableDates(reserved)) cbDate.addItem(d);
            } catch (IOException ex) {
                showConnErr(reserveFrame, ex);
            }
        };

        Runnable refillSports = () -> {
            String date = (String) cbDate.getSelectedItem();
            if (date == null) return;
            try {
                Set<String> reserved = fetchReservations();
                cbSport.removeAllItems();
                for (String s : AddNewReservations.computeAvailableSports(date, reserved)) cbSport.addItem(s);
            } catch (IOException ex) {
                showConnErr(reserveFrame, ex);
            }
        };

        Runnable refillTimes = () -> {
            String date = (String) cbDate.getSelectedItem();
            String sport = (String) cbSport.getSelectedItem();
            if (date == null || sport == null) return;
            try {
                Set<String> reserved = fetchReservations();
                cbTime.removeAllItems();
                for (String t : AddNewReservations.computeAvailableTimes(date, sport, reserved)) cbTime.addItem(t);
            } catch (IOException ex) {
                showConnErr(reserveFrame, ex);
            }
        };

        Runnable refillFields = () -> {
            String date = (String) cbDate.getSelectedItem();
            String sport = (String) cbSport.getSelectedItem();
            String time = (String) cbTime.getSelectedItem();
            if (date == null || sport == null || time == null) return;
            try {
                Set<String> reserved = fetchReservations();
                cbField.removeAllItems();
                for (String f : AddNewReservations.computeAvailableFields(date, sport, time, reserved)) cbField.addItem(f);
            } catch (IOException ex) {
                showConnErr(reserveFrame, ex);
            }
        };

        // fill on open
        refillDates.run();

        cbDate.addActionListener(e -> {
            cbSport.removeAllItems(); cbTime.removeAllItems(); cbField.removeAllItems();
            refillSports.run();
        });

        cbSport.addActionListener(e -> {
            cbTime.removeAllItems(); cbField.removeAllItems();
            refillTimes.run();
        });

        cbTime.addActionListener(e -> {
            cbField.removeAllItems();
            refillFields.run();
        });

        btnRefresh.addActionListener(e -> {
            refillDates.run();
            cbSport.removeAllItems(); cbTime.removeAllItems(); cbField.removeAllItems();
        });

        btnBook.addActionListener(e -> {
            String date  = (String) cbDate.getSelectedItem();
            String sport = (String) cbSport.getSelectedItem();
            String time  = (String) cbTime.getSelectedItem();
            String field = (String) cbField.getSelectedItem();

            if (date == null || sport == null || time == null || field == null) {
                JOptionPane.showMessageDialog(reserveFrame, "Please fill all fields before booking.", "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(reserveFrame,
                    "Confirm reservation?\n\nDate: " + date +
                            "\nSport: " + sport +
                            "\nTime: " + time +
                            "\nField: " + field,
                    "Confirm Reservation", JOptionPane.YES_NO_OPTION);

            if (confirm != JOptionPane.YES_OPTION) return;

            try {
                String resp = sendReserve(sport, date, time, field);
                if (resp != null && resp.startsWith("CONFIRMED")) {
                    JOptionPane.showMessageDialog(reserveFrame, "Reservation confirmed!\n" + resp);
                    // بعد الحجز نعيد تعبئة القوائم من LIST
                    refillDates.run();
                    cbSport.removeAllItems(); cbTime.removeAllItems(); cbField.removeAllItems();
                } else {
                    JOptionPane.showMessageDialog(reserveFrame, (resp == null ? "No response from server." : resp), "Reservation", JOptionPane.WARNING_MESSAGE);
                }
            } catch (IOException ex) {
                showConnErr(reserveFrame, ex);
            }
        });

        reserveFrame.setVisible(true);
    }

    private void showConnErr(Component parent, IOException ex) {
        JOptionPane.showMessageDialog(parent, "Connection error: " + ex.getMessage(), "Network", JOptionPane.ERROR_MESSAGE);
    }

    // =========================
    //   Server interactions
    // =========================
    private Set<String> fetchReservations() throws IOException {
        ensureConnected();
        out.println("LIST");
        out.flush();

        Set<String> keys = new HashSet<>();
        String line;
        while ((line = in.readLine()) != null) {
            if ("END".equals(line)) break;
            if (!line.trim().isEmpty()) keys.add(line.trim());
        }
        return keys;
    }

    private String sendReserve(String sport, String day, String time, String field) throws IOException {
        ensureConnected();
        // ترميز الفراغات إلى _
        String s = sport.replace(' ', '_');
        String d = day.replace(' ', '_');
        String t = time.replace(' ', '_');
        String f = field.replace(' ', '_');
        out.println("RESERVE " + s + " " + d + " " + t + " " + f);
        out.flush();
        return in.readLine();
    }

    private void ensureConnected() throws IOException {
        if (socket == null || socket.isClosed()) {
            socket = new Socket(SERVER_IP, SERVER_PORT);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
        }
    }

    // ============== (اختياري) CLI قديم لو حبيتي ==============
    @SuppressWarnings("unused")
    private void runCLI() throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("=== SportifyHub Client ===");
        System.out.println("1) Register new account");
        System.out.println("2) Login to existing account");
        System.out.print("Choose: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline
        // ... يمكنك إعادة استخدام المنطق أعلاه إن احتجتِ CLI
        scanner.close();
    }
}
