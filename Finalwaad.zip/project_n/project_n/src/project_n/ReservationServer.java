/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project_n;

/**
 *
 * @author memem
 */
import java.io.*; 
import java.net.Socket;
import java.net.ServerSocket;
import java.util.ArrayList;

public class ReservationServer {
    private static ArrayList<ClientHandler> clients = new ArrayList<>();
    private static ArrayList<String> usernames = new ArrayList<>();
    private static ArrayList<String> passwords = new ArrayList<>();
    private static ArrayList<String> reservedSlots = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(9090);
        System.out.println("Server started on port 9090");

        while (true) {
            System.out.println("Waiting for client connection...");
            Socket client = serverSocket.accept();
            System.out.println("Connected to client");
            ClientHandler clientThread = new ClientHandler(client, clients, usernames, passwords, reservedSlots);
            clients.add(clientThread);
            new Thread(clientThread).start();
        }
    }
}