/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package network_project;

/**
 *
 * @author FATIMAH
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.Socket;

public class Client {

    // ====== Server information ======
    private static final String Server_IP = "localhost";
    private static final int Server_port = 9090;

    // ====== GUI Components ======
    private JFrame frame;
    private JTextArea textArea;
    private JTextField inputField;
    private JButton sendButton;

    // ====== Networking Components ======
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;

    public Client() {
        // ===== Create GUI Window =====
        frame = new JFrame("Reservation Client");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Text area to display messages from the server
        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        frame.add(new JScrollPane(textArea), BorderLayout.CENTER);

        // Input field and send button
        inputField = new JTextField();
        sendButton = new JButton("Send");

        // Panel to hold input + button
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(inputField, BorderLayout.CENTER);
        bottomPanel.add(sendButton, BorderLayout.EAST);
        frame.add(bottomPanel, BorderLayout.SOUTH);

        // Display the window
        frame.setVisible(true);

        // ===== Event handling =====
        ActionListener sendAction = e -> {
            String userInput = inputField.getText();
            if (!userInput.isEmpty()) {
                out.println(userInput); // send user input to the server
                inputField.setText(""); // clear text field
            }
        };

        sendButton.addActionListener(sendAction);
        inputField.addActionListener(sendAction); // allow pressing Enter to send
    }

    // ===== Start client connection =====
    public void startClient() {
        try {
            // Try to connect to the server
            socket = new Socket(Server_IP, Server_port);
            textArea.append("Connected to server!\n");

            // Input/output setup
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            // ===== Thread to receive messages from server =====
            new Thread(() -> {
                try {
                    String serverResponse;
                    while ((serverResponse = in.readLine()) != null) {
                        textArea.append(serverResponse + "\n");

                        // Pop-up messages for confirmation or rejection
                        if (serverResponse.startsWith("CONFIRMED")) {
                            JOptionPane.showMessageDialog(frame, serverResponse, "Reservation Confirmed", JOptionPane.INFORMATION_MESSAGE);
                        } else if (serverResponse.startsWith("REJECTED")) {
                            JOptionPane.showMessageDialog(frame, serverResponse, "Reservation Rejected", JOptionPane.WARNING_MESSAGE);
                        }

                        // Close client if server says Goodbye
                        if (serverResponse.contains("Goodbye!")) {
                            break;
                        }
                    }
                } catch (IOException e) {
                    textArea.append("Connection closed.\n");
                }
            }).start();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Connection Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void sendReservation(String date, String time) {
    if (out != null) {
        String command = "RESERVE "+ date + " " + time;
        out.println(command);
    } else {
        System.out.println("⚠️ Connection not established. Cannot send reservation.");
    }}

    // ===== Main method =====
    public static void main(String[] args) {
        Client client = new Client();
        client.startClient();
    }
}
/*
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Client {
    private static final String Server_IP ="localhost"; //------- Server IP and port # -----------
    private static final int Server_port =9090;
    
 
        public static void main(String[] args) throws IOException{
            
          try(Socket socket = new Socket (Server_IP,Server_port)) { //try block to be excuted only if connection is established
                          System.out.println("Connected to server!");

             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream())); // variable that will get input from the server
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);// variable that will send userinput from the server
             BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in)); // variable that will get userinput
              
            String serverLine;
            while ((serverLine = in.readLine()) != null) {
                
                // Always print all responses from the server
                System.out.println(serverLine);
                
                // If the message is final (Goodbye), break the loop
                if (serverLine.contains("Goodbye!")) {
                    break;
                }
                
                // Read user input and send to server
                String userInput = keyboard.readLine();
                if (userInput == null) {
                    break; 
                }
                out.println(userInput); // Send command to the server
                              
            }


        } catch (IOException e) {
            System.out.println("Connection error: " + e.getMessage()); //error message if try block fails execution
        }

        System.out.println("Client closed.");
    }
}*/