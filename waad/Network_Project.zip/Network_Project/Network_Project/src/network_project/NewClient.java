/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package network_project;

/**
 *
 * @author FATIMAH
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

class NewClient implements Runnable{ //server thread
private Socket client;
private BufferedReader in;
private PrintWriter out;
private ArrayList<NewClient> clients; 
    private ArrayList<String> usernames;
    private ArrayList<String> passwords;
    


  public NewClient (Socket c,ArrayList<NewClient> clients, ArrayList<String> usernames,ArrayList<String> passwords ) throws IOException
  {
    this.client = c;
    this.clients=clients;
    in= new BufferedReader (new InputStreamReader(client.getInputStream())); 
    out=new PrintWriter(client.getOutputStream(),true); 
    this.usernames = usernames;
    this.passwords = passwords;
  }

@Override
  public void run ()
  {
   try{
    while (true){
    

            // Step 1: Ask for username and password
            out.println("");
            String username = in.readLine();

            out.println("");
            String password = in.readLine();

            // Step 2: Check if username exists
            synchronized (usernames) {
                if (usernames.contains(username)) {
                    out.println("Username already exists! Please try again.");
                    client.close();
                    return;
                } else {
                    // Step 3: Save user
                    usernames.add(username);
                    passwords.add(password);
                    out.println("Registration successful! Welcome, " + username + "!");
                }
            }
            
            // Step 4: After register, user can send commands (for later use)
            String line;
            while ((line = in.readLine()) != null) {
                out.println("You said: " + line); //===============================RESERVATION SYSTEM CODE TO BE CONTINUED BY REPLACING THIS
            }
   
    }
}
    catch (IOException e) {
            System.out.println("Client disconnected.");
        } finally {
            try {
                client.close();
            } catch (IOException e) {
                System.out.println("Error closing connection.");
            }
        }
    }
}
